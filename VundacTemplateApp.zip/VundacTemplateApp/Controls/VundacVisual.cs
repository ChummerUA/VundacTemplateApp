﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace $safeprojectname$.Controls
{
    public class VundacVisual : IVisual
    {
    }
}
